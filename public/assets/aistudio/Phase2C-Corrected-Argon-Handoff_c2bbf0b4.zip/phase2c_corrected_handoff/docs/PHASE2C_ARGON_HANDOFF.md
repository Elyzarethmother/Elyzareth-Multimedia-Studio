# PHASE 2C — CORRECTED IMPLEMENTATION HANDOFF FOR ARGON 4

**Status:** Implementation authorization after independent review of `Edits-Phase 2.txt`.

**Baseline:** Use the latest supplied Music Video Studio repository and preserve its existing architecture. The currently supplied Gradle wrapper configuration declares **Gradle 9.3.1**. Do not use Gradle 8.7.

## 1. Mandatory corrections to the proposed document

### 1.1 WorkManager Data contract — strict

`Data` passed to `LocalImportWorker` MUST contain exactly one application field: `jobId`.

Do not put `sourceUri`, `sceneId`, prompt, metadata, or media bytes in WorkManager Data. WorkManager Data is a small scheduling payload, not the job database.

Persist in Room:
- job kind (`LOCAL_IMPORT` versus any future provider-generation job);
- source URI string;
- persisted URI grant flags, if applicable;
- scene ID (already present on the job);
- job status and timestamps;
- resulting `assetId`.

For Android document-picker imports, obtain and persist the URI permission when the picker contract supports it. The app must not enqueue work against a URI permission it cannot retain. If the URI grant cannot be persisted, copy the selected file into app-owned staging synchronously before scheduling, or report a clear import failure; do not enqueue a URI that will become inaccessible after process death.

The worker loads the job from Room using `jobId`, validates `jobKind == LOCAL_IMPORT`, and reads source URI and scene ID from that row. It must be idempotent: if the job is already `COMPLETED` with a valid manifest, return success without creating another asset.

### 1.2 Worker state transitions

The existing state machine does not currently permit `QUEUED -> DOWNLOADING`. Do not bypass the state machine or silently add arbitrary transitions.

Implement an explicit local-import transition path, for example:
`QUEUED -> DOWNLOADING -> VALIDATING -> COMPLETED`.

If the enum transition function is shared with provider jobs, distinguish job kind when validating transitions. A local import is not a provider POST and must never enter `SUBMITTING` or `AMBIGUOUS_SUBMISSION_FAILED`.

Only retry local import work when its source remains readable and the staged copy is safely restartable. Never automatically retry a future ambiguous billable provider POST.

### 1.3 EDL asset boundary

Remove `videoClipPath` from:
- `EdlSceneClip`;
- `SceneVersionSnapshot`;
- `StoryboardCue`;
- any EDL serialization/history representation.

EDL stores only the provider-independent immutable `assetId`. `AssetManager`/manifest resolves the asset to an app-owned Content URI or file at the rendering boundary. Do not persist absolute paths in the EDL, version snapshots, undo/redo history or storyboard cues.

`attachVerifiedAssetToScene`, `restoreSceneVersion`, and `toStoryboardCues` must carry only `assetId`. Preserve photo-only scenes and existing scene timing.

### 1.4 MP4 parser — use Android media APIs, not a partial hand-written parser

The proposed parser in `Edits-Phase 2.txt` is incomplete: the `minf`/`stbl` handling is only a comment. It does not parse sample descriptions, `stts`, `ctts` or a valid presentation timeline. Do not merge that incomplete parser.

Prefer Android `MediaExtractor` for video track metadata and presentation sample timestamps:
- open the app-owned staged file with `MediaExtractor.setDataSource(file.absolutePath)`;
- identify the `video/*` track from `MediaFormat.KEY_MIME`;
- obtain width, height, duration and nominal frame rate where available;
- select only the video track;
- scan sample presentation timestamps incrementally; do not store every timestamp in memory;
- compute cadence statistics online and write only a bounded/sparse PTS manifest (for example, at most 4,096 representative timestamps);
- mark analysis as truncated/approximate if a safety limit is reached before EOS;
- release `MediaExtractor` in `finally`/`use`-equivalent cleanup.

Do not claim definitive VFR classification if analysis was truncated. A full scan may be performed in the background worker; memory use must remain O(1) apart from the bounded PTS sample list.

`MediaExtractor` metadata is not proof that a frame can be decoded. If decodability is a validation requirement, verify it separately with `MediaMetadataRetriever` or a decoder path and release the resource correctly. Do not label “has mdat + video track” as a decodable frame.

### 1.5 Durable promotion ownership — no filename guessing

The proposed fallback `file.name.contains(jobId)` is not acceptable. Neither scene ID nor substring matching proves ownership.

Add a durable promotion journal (Room entity/table) containing at minimum:
- `jobId` (unique owner);
- `assetId` (unique);
- staging relative path;
- final relative path;
- expected SHA-256;
- promotion phase (`PREPARED`, `PROMOTED`, `COMMITTED`);
- created/updated timestamps.

Write `PREPARED` to Room before promotion. Promote the file atomically on the same filesystem. Update the journal to `PROMOTED`. Then, in one Room transaction, insert/verify the asset manifest, complete exactly the journal's `jobId`, and mark the journal `COMMITTED`.

At startup:
- `PREPARED` + staging file exists: safely resume validation/promotion for that exact job.
- `PREPARED` + neither staging nor final exists: mark that exact local job failed/recoverable according to policy.
- `PROMOTED` + final file exists and checksum matches: commit that exact job and manifest transactionally.
- `PROMOTED` + final file missing or checksum mismatch: do not register the manifest; mark that exact job failed and retain diagnostics.
- `COMMITTED`: verify the manifest reference; do not create another asset.

Do not scan all unfinished jobs for a scene and assign one orphan to an arbitrary job.

### 1.6 Room transaction

Use `RoomDatabase.withTransaction {}`. Within the transaction:
1. load the exact job;
2. verify its current state permits completion;
3. insert the immutable manifest if absent, rejecting an `assetId`/SHA collision;
4. update the exact job to `COMPLETED` with the `resultAssetId`;
5. mark its promotion journal `COMMITTED`.

If any required compare-and-set returns false, throw or otherwise abort the transaction. Do not return normally after a partial write.

### 1.7 Database migration

The current database is version 1. Adding local-import metadata and a promotion journal requires a real migration (for example version 2), not an empty placeholder migration.

Enable `exportSchema = true`, configure KSP schema output, check in the generated version-1 and version-2 schema JSON, and write a migration test from the actual version-1 schema. Do not use destructive migration.

### 1.8 Gradle wrapper

The supplied `gradle/wrapper/gradle-wrapper.properties` specifies:
`https://services.gradle.org/distributions/gradle-9.3.1-bin.zip`

Restore:
- `gradlew`;
- `gradlew.bat`;
- `gradle/wrapper/gradle-wrapper.jar`;

using Gradle **9.3.1**. Do not downgrade to 8.7. Do not hand-create a fake wrapper JAR.

## 2. Target files

Inspect and modify the real repository paths, including:
- `StudioDatabase.kt`;
- `GenerationJobEntity.kt`, `GenerationJobDao.kt`, `GenerationJobStatus.kt`;
- `AssetManifestEntity.kt`, `AssetManifestDao.kt`;
- new promotion-journal entity/DAO;
- `StudioModels.kt`;
- `EdlTimelineEngine.kt`;
- `MediaAssetValidator.kt` / VFR detector;
- `AssetManager.kt`, `AtomicFilePromoter.kt`;
- `StorageReconciliationManager.kt`;
- `GenerationWorkOrchestrator.kt`;
- new `LocalImportWorker.kt`;
- `MusicVideoViewModel.kt`;
- `app/build.gradle.kts`, `gradle/libs.versions.toml`, KSP schema configuration;
- Room migration and integration tests.

Do not assume every target class has the exact signatures shown in the earlier proposal. Inspect the repository and adapt safely.

## 3. Required acceptance tests

See `tests/ACCEPTANCE_TESTS.md`. At minimum:
- actual Room SQLite transaction rollback;
- v1-to-v2 migration;
- unique WorkManager work using `KEEP` and Data containing only `jobId`;
- worker loads URI/scene from Room;
- worker restart and idempotency;
- promotion-journal recovery for each crash window;
- no cross-job recovery;
- EDL models/history contain assetId but no filesystem path;
- MediaExtractor probe on audio+video MP4 and VFR/CFR fixtures;
- bounded memory/PTS list;
- decoder verification is distinct from track discovery.

## 4. Build and reporting

Run with the restored wrapper:
```bash
./gradlew --version
./gradlew :app:testDebugUnitTest
./gradlew :app:assembleDebug
```

Run relevant instrumented tests where available. Return:
- updated repository ZIP;
- exact changed-file list;
- generated Room schema files;
- migration test output;
- test and build logs;
- APK path and SHA-256;
- explicit labels for JVM-tested, Room-tested, WorkManager-tested, instrumented-tested and physically device-tested.

**Stop after Phase 2C. No Gemini/Omni/Veo provider integration, backend deployment, VFR rendering, exporter redesign, unrelated UI redesign, payments, subscriptions or commercial features.** Submit the repository for independent GPT audit before Phase 3.
