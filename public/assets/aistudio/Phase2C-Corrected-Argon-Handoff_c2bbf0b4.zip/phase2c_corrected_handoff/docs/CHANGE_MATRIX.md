# Change matrix

| Area | Target | Required correction | Sign-off evidence |
|---|---|---|---|
| Room | `StudioDatabase.kt` | Real `withTransaction` commit of manifest + job + journal | Forced rollback test |
| Schema | `GenerationJobEntity.kt` | Persist `jobKind`, source URI and URI grant flags for local imports | v1→v2 migration test |
| Recovery | New promotion journal entity/DAO | Durable exact `jobId` ↔ `assetId` association | Crash-window recovery tests |
| EDL | `StudioModels.kt` | Remove physical path from EDL and snapshots | Serialization/model assertions |
| EDL | `EdlTimelineEngine.kt` | Attach/restore/cue using assetId only | Version restore tests |
| Media | `MediaAssetValidator.kt` | MediaExtractor-based track and presentation-time scan | CFR/VFR and A/V fixtures |
| Media | `AssetManager.kt` | Stage, validate, journal, promote, transactionally commit | Idempotent import tests |
| WorkManager | `LocalImportWorker.kt` | Input Data contains only jobId; fetch rest from Room | Data-key and worker tests |
| WorkManager | `GenerationWorkOrchestrator.kt` | Unique work name per local import job, ExistingWorkPolicy.KEEP | Duplicate enqueue test |
| UI | `MusicVideoViewModel.kt` | Persist URI grant, create Room job, enqueue worker, observe Room | ViewModel integration test |
| Build | Gradle wrapper | Restore Gradle 9.3.1 wrapper | `./gradlew --version` |
| Build | Room schema | exportSchema + KSP schema output + migration test | Schema JSON + migration output |
