package com.example.studio.ingestion

import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import kotlin.math.abs
import kotlin.math.max

/**
 * Bounded-memory video-track probe.
 *
 * MediaExtractor.sampleTime is a presentation timestamp in microseconds.
 * This probe scans incrementally and retains no more than maxPtsEntries timestamps.
 * A complete scan is O(number of samples) time and O(maxPtsEntries) memory.
 *
 * A truncated scan must be reported as approximate; do not claim definitive VFR status.
 */
data class ExtractorProbeResult(
    val hasVideoTrack: Boolean,
    val mime: String?,
    val width: Int,
    val height: Int,
    val durationUs: Long,
    val nominalFrameRate: Int?,
    val isVfr: Boolean?,
    val scanComplete: Boolean,
    val sampledPtsUs: List<Long>,
    val error: String? = null
)

object MediaExtractorProbe {
    fun inspect(
        file: File,
        maxSamplesToScan: Long = Long.MAX_VALUE,
        maxPtsEntries: Int = 4096
    ): ExtractorProbeResult {
        require(maxSamplesToScan > 0)
        require(maxPtsEntries >= 2)

        if (!file.isFile || file.length() <= 0L) {
            return ExtractorProbeResult(false, null, 0, 0, 0, null, null, true, emptyList(), "File missing/empty")
        }

        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(file.absolutePath)

            var videoTrack = -1
            var videoFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/")) {
                    videoTrack = i
                    videoFormat = format
                    break
                }
            }

            if (videoTrack < 0 || videoFormat == null) {
                return ExtractorProbeResult(false, null, 0, 0, 0, null, null, true, emptyList(), "No video track")
            }

            val format = videoFormat
            val mime = format.getString(MediaFormat.KEY_MIME)
            val width = if (format.containsKey(MediaFormat.KEY_WIDTH)) format.getInteger(MediaFormat.KEY_WIDTH) else 0
            val height = if (format.containsKey(MediaFormat.KEY_HEIGHT)) format.getInteger(MediaFormat.KEY_HEIGHT) else 0
            val durationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L
            val fps = if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) format.getInteger(MediaFormat.KEY_FRAME_RATE) else null

            extractor.selectTrack(videoTrack)

            val pts = ArrayList<Long>(maxPtsEntries)
            var previousPts = Long.MIN_VALUE
            var firstDelta: Long? = null
            var vfr = false
            var samples = 0L
            var scanComplete = false

            while (samples < maxSamplesToScan) {
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs < 0L) {
                    scanComplete = true
                    break
                }

                if (previousPts != Long.MIN_VALUE) {
                    val delta = sampleTimeUs - previousPts
                    if (delta > 0L) {
                        val baseline = firstDelta
                        if (baseline == null) {
                            firstDelta = delta
                        } else {
                            // Conservative cadence variance tolerance: 2% or 1 ms.
                            val tolerance = max(1_000L, (baseline * 0.02).toLong())
                            if (abs(delta - baseline) > tolerance) vfr = true
                        }
                    }
                }

                // Sparse, bounded timeline samples; never accumulate every frame PTS.
                if (pts.size < maxPtsEntries) {
                    pts += sampleTimeUs
                } else if (samples % maxOf(1L, maxSamplesToScan / maxPtsEntries) == 0L) {
                    val slot = ((samples / maxOf(1L, maxSamplesToScan / maxPtsEntries)) % maxPtsEntries).toInt()
                    pts[slot] = sampleTimeUs
                }

                previousPts = sampleTimeUs
                samples++
                if (!extractor.advance()) {
                    scanComplete = true
                    break
                }
            }

            return ExtractorProbeResult(
                hasVideoTrack = true,
                mime = mime,
                width = width,
                height = height,
                durationUs = durationUs,
                nominalFrameRate = fps,
                isVfr = if (scanComplete) vfr else null,
                scanComplete = scanComplete,
                sampledPtsUs = pts
            )
        } catch (e: Exception) {
            return ExtractorProbeResult(false, null, 0, 0, 0, null, null, false, emptyList(), e.message)
        } finally {
            extractor.release()
        }
    }
}
