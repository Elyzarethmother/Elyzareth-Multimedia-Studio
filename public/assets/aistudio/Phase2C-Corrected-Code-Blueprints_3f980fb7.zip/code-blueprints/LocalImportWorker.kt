package com.example.studio.storage.workers

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.studio.storage.db.GenerationJobKind
import com.example.studio.storage.db.GenerationJobStatus
import com.example.studio.storage.db.StudioDatabase
import com.example.studio.ingestion.AssetManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * WorkManager Data contract: exactly one app-defined input key, jobId.
 * Source URI and sceneId are read from Room.
 *
 * Adapt constructor/AssetManager calls to the actual project signatures.
 */
class LocalImportWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val jobId = inputData.getString(KEY_JOB_ID)
            ?: return@withContext Result.failure()

        // Defensive contract check: reject accidental payload expansion.
        if (inputData.keyValueMap.keys != setOf(KEY_JOB_ID)) {
            return@withContext Result.failure()
        }

        val db = StudioDatabase.getInstance(applicationContext)
        val dao = db.generationJobDao()
        val job = dao.getJob(jobId) ?: return@withContext Result.failure()

        if (job.jobKind != GenerationJobKind.LOCAL_IMPORT) {
            return@withContext Result.failure()
        }

        if (job.status == GenerationJobStatus.COMPLETED) {
            val assetId = job.resultAssetId ?: return@withContext Result.failure()
            return@withContext if (db.assetManifestDao().getByAssetId(assetId) != null) {
                Result.success()
            } else {
                Result.failure()
            }
        }
        if (job.status.isTerminal) return@withContext Result.failure()

        val source = job.sourceUri
            ?: return@withContext Result.failure()

        // URI permission must have been persisted before enqueue. Do not silently retry
        // a permanently inaccessible URI.
        try {
            val uri = android.net.Uri.parse(source)
            val assetManager = AssetManager(applicationContext.filesDir, db)

            // This operation must be idempotent for jobId and must journal ownership
            // before promotion. It must not create a second asset if a previous attempt
            // already promoted/committed one.
            val result = assetManager.ingestLocalMp4ForJob(
                jobId = jobId,
                sceneId = job.sceneId,
                sourceUri = uri
            )

            if (result.isSuccess) Result.success()
            else Result.failure()
        } catch (e: SecurityException) {
            dao.transitionStatus(
                jobId = jobId,
                targetStatus = GenerationJobStatus.FAILED,
                errorMessage = "Persisted source URI permission is unavailable: ${e.message}"
            )
            Result.failure()
        } catch (e: Exception) {
            // Worker retry policy must be explicit. Retry only when the staged copy can
            // be safely resumed and the URI grant is still valid. Otherwise fail.
            Result.failure()
        }
    }

    companion object {
        const val KEY_JOB_ID = "jobId"
    }
}
