// Pattern for StudioDatabase.kt. Adapt DAO method names to the checked-out source.
// Do not keep an ineffective @Transaction annotation on a RoomDatabase method.

suspend fun commitPromotedAsset(
    jobId: String,
    manifest: AssetManifestEntity,
    journalId: String,
    nowEpochMs: Long = System.currentTimeMillis()
): Boolean = withTransaction {
    val jobDao = generationJobDao()
    val assetDao = assetManifestDao()
    val journalDao = promotionJournalDao()

    val job = jobDao.getJob(jobId) ?: return@withTransaction false
    val journal = journalDao.getById(journalId)
        ?: error("Missing promotion journal: $journalId")

    check(journal.jobId == jobId) { "Promotion journal owner mismatch" }
    check(journal.assetId == manifest.assetId) { "Promotion journal asset mismatch" }
    check(job.status == GenerationJobStatus.VALIDATING) {
        "Unexpected job state ${job.status}; expected VALIDATING"
    }

    val existing = assetDao.getByAssetId(manifest.assetId)
    if (existing != null) {
        check(existing.sha256Hex.equals(manifest.sha256Hex, ignoreCase = true)) {
            "Immutable assetId collision: ${manifest.assetId}"
        }
    } else {
        assetDao.insertManifestIfAbsent(manifest)
    }

    val updated = jobDao.transitionStatus(
        jobId = jobId,
        targetStatus = GenerationJobStatus.COMPLETED,
        resultAssetId = manifest.assetId,
        errorMessage = null,
        nowEpochMs = nowEpochMs
    )
    check(updated) { "Job compare-and-set failed; transaction must roll back" }

    val journalUpdated = journalDao.markCommitted(
        journalId = journalId,
        committedAtEpochMs = nowEpochMs
    )
    check(journalUpdated) { "Promotion journal commit failed; transaction must roll back" }

    true
}
