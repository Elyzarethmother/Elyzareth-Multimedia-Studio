# Promotion journal protocol

## Room entity (required fields)

Create a Room entity with:
- `journalId: String` primary key;
- `jobId: String` unique index;
- `assetId: String` unique index;
- `stagingRelativePath: String`;
- `finalRelativePath: String`;
- `expectedSha256Hex: String`;
- `phase: PromotionPhase` (`PREPARED`, `PROMOTED`, `COMMITTED`);
- `createdAtEpochMs`, `updatedAtEpochMs`.

Add DAO operations that use compare-and-set phase updates and fetch by exact `jobId` or `assetId`.

## Required order

1. Validate staged media and compute SHA-256.
2. In Room, insert `PREPARED` journal for exact `(jobId, assetId)`.
3. Atomically rename staged file to final path on the same filesystem.
4. In Room, update journal to `PROMOTED`.
5. In one `withTransaction` block: insert/verify manifest, complete exact job with `resultAssetId`, mark journal `COMMITTED`.

The journal must be written before promotion so a process death between rename and manifest commit remains attributable.

## Recovery

Recovery iterates journal rows, not arbitrary files/jobs:
- PREPARED + staging exists: resume validation and promotion for that journal/job.
- PREPARED + final exists and checksum matches: advance to PROMOTED and commit.
- PROMOTED + final exists and checksum matches: commit exact journal/job.
- PROMOTED + final missing or hash mismatch: fail the exact job and preserve diagnostics.
- COMMITTED: verify manifest exists; never create a second asset.
- If neither staging nor final exists for PREPARED, mark the exact job failed/recoverable and clear the journal only under an explicit cleanup policy.

Never associate by sceneId, filename substring, first matching job, or directory enumeration order.
