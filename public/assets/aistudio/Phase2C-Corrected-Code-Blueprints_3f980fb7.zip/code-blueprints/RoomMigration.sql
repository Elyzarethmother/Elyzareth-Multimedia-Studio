-- Illustrative SQLite migration from the supplied v1 job schema to v2.
-- Argon MUST verify exact table/column names against the exported v1 Room schema JSON.
-- Use Room Migration(1, 2); do not use fallbackToDestructiveMigration().

ALTER TABLE generation_jobs ADD COLUMN jobKind TEXT NOT NULL DEFAULT 'PROVIDER_GENERATION';
ALTER TABLE generation_jobs ADD COLUMN sourceUri TEXT;
ALTER TABLE generation_jobs ADD COLUMN sourceUriGrantFlags INTEGER NOT NULL DEFAULT 0;

CREATE TABLE IF NOT EXISTS promotion_journal (
    journalId TEXT NOT NULL PRIMARY KEY,
    jobId TEXT NOT NULL,
    assetId TEXT NOT NULL,
    stagingRelativePath TEXT NOT NULL,
    finalRelativePath TEXT NOT NULL,
    expectedSha256Hex TEXT NOT NULL,
    phase TEXT NOT NULL,
    createdAtEpochMs INTEGER NOT NULL,
    updatedAtEpochMs INTEGER NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS index_promotion_journal_jobId
ON promotion_journal(jobId);

CREATE UNIQUE INDEX IF NOT EXISTS index_promotion_journal_assetId
ON promotion_journal(assetId);
