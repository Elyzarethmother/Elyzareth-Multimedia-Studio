# Phase 2C acceptance tests

## Room and migration
1. Build the actual Room v1 schema, insert representative v1 rows, migrate to v2, and verify all previous values survive.
2. Verify new job fields and promotion journal schema.
3. Force the job state compare-and-set to fail after manifest insertion; verify the entire transaction rolls back and no manifest/journal partial state remains.
4. Verify duplicate `assetId` with a different SHA-256 is rejected.
5. Reopen the database and verify job, manifest and journal persistence.

## WorkManager
1. Enqueue local import with `ExistingWorkPolicy.KEEP` and a stable unique name derived from `jobId`.
2. Assert `Data.keyValueMap.keys == setOf("jobId")`.
3. Assert source URI and scene ID are loaded from Room, not WorkManager Data.
4. Enqueue twice for the same job; verify one logical execution and one resulting asset.
5. Kill/recreate worker execution at copy, validation, PREPARED, PROMOTED and COMMITTED boundaries; verify journal-based recovery.
6. Verify local import never enters SUBMITTING or AMBIGUOUS_SUBMISSION_FAILED.

## EDL
1. Assert `EdlSceneClip`, `SceneVersionSnapshot`, `StoryboardCue`, EDL serializer and history contain `assetId` but no `videoClipPath` or absolute filesystem path.
2. Attach an asset, undo/redo, restore earlier scene version, and verify the correct assetId is restored.
3. Verify photo-only scenes remain unchanged.
4. Verify renderer resolves assetId through manifest/AssetManager rather than reading a path from EDL.

## Media
1. Test MP4 with both audio and video; ensure only video track metadata and timestamps are used.
2. Test CFR and VFR fixtures; verify presentation timestamps from MediaExtractor.
3. Test a file larger than available heap assumptions; verify no whole-file byte array allocation.
4. Verify PTS manifest stays within configured bound.
5. Verify truncated scans return `isVfr = null` / approximate, not definitive.
6. Test a corrupt file, no-video file, unsupported codec and zero-duration metadata.
7. If decodable-frame validation is claimed, test actual decoder/MediaMetadataRetriever separately.

## Build and evidence
Run:
- `./gradlew --version` (must report Gradle 9.3.1)
- `./gradlew :app:testDebugUnitTest`
- `./gradlew :app:assembleDebug`
- relevant connected/instrumented tests when available.

Report tests only when executed. Distinguish JVM, Room SQLite, WorkManager, instrumented and physical-device results.
