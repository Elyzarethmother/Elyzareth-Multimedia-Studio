# Phase 2C corrected handoff package

This package corrects the proposed implementation instructions in `Edits-Phase 2.txt`.

It is an implementation handoff for Argon, not a claim that the supplied repository has already been modified, compiled, or tested.

## Package contents
- `docs/PHASE2C_ARGON_HANDOFF.md`: authoritative corrected scope and acceptance criteria.
- `docs/CHANGE_MATRIX.md`: exact target files and required outcomes.
- `code-blueprints/StudioDatabase_transaction.kt`: Room transaction pattern.
- `code-blueprints/LocalImportWorker.kt`: WorkManager worker pattern. WorkManager Data contains only `jobId`; URI and scene ID are loaded from Room.
- `code-blueprints/MediaExtractorProbe.kt`: bounded-memory Android MediaExtractor probe pattern. It does not load the MP4 into memory.
- `code-blueprints/PromotionJournal.md`: durable job-to-asset ownership and crash recovery protocol.
- `code-blueprints/RoomMigration.sql`: migration outline; Argon must align it with the actual schema and generated Room schema.
- `tests/ACCEPTANCE_TESTS.md`: tests required before sign-off.

## Important baseline
The supplied project wrapper configuration specifies Gradle 9.3.1. Do not downgrade to Gradle 8.7. Restore the matching wrapper scripts and `gradle-wrapper.jar`, or regenerate them using Gradle 9.3.1.

## Usage
Argon must inspect the actual current repository and adapt package imports, constructor signatures, DAO names and migration SQL to the real source. These blueprints are authoritative behavior requirements, not blindly pasteable replacements for every file.

No Phase 3 provider integration is authorized.
