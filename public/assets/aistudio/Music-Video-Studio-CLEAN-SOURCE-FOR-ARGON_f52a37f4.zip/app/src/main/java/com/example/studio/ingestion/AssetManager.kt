package com.example.studio.ingestion

import android.content.Context
import android.net.Uri
import com.example.studio.storage.db.AssetManifestEntity
import com.example.studio.storage.db.GenerationJobEntity
import com.example.studio.storage.db.GenerationJobStatus
import com.example.studio.storage.db.StudioDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.security.MessageDigest
import java.util.Locale

/**
 * Owns the provider-independent media ingestion lifecycle:
 * - Staging file allocation (`filesDir/.staging_tmp/job_<jobId>.part`)
 * - Streaming InputStream / ContentResolver copy
 * - Streaming SHA-256 verification (`ChecksumVerifier`)
 * - Container, track, codec, dimension, duration & VFR validation (`MediaAssetValidator` + `VfrDetector`)
 * - POSIX atomic file promotion (`AtomicFilePromoter`) into `filesDir/studio_assets/<assetId>.mp4`
 * - Transactional Room manifest registration & job completion (`StudioDatabase`)
 * - Immutable `AssetDescriptor` lookup and Content URI resolution by `assetId`
 */
class AssetManager(
    private val baseFilesDir: File,
    private val database: StudioDatabase,
    private val validatorInspector: VideoContainerInspector = MediaAssetValidator.defaultInspector
) {

    val stagingDir: File = File(baseFilesDir, ".staging_tmp").apply { mkdirs() }
    val studioAssetsDir: File = File(baseFilesDir, "studio_assets").apply { mkdirs() }
    val studioMetadataDir: File = File(baseFilesDir, "studio_metadata").apply { mkdirs() }

    private val atomicPromoter = AtomicFilePromoter(studioAssetsDir)

    /**
     * Allocates a staging file in `filesDir/.staging_tmp/job_<jobId>.part` on the same
     * filesystem mount as `filesDir/studio_assets/`.
     */
    fun allocateStagingFile(jobId: String): File {
        stagingDir.mkdirs()
        val safeJobId = jobId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        return File(stagingDir, "job_$safeJobId.part")
    }

    /**
     * Computes a deterministic client-side idempotency key from the scene, prompt, provider, and seed.
     */
    fun computeIdempotencyKey(
        sceneId: String,
        providerId: String,
        modelId: String,
        prompt: String,
        seedOrSourceKey: String
    ): String {
        val raw = "$sceneId|$providerId|$modelId|${prompt.trim()}|$seedOrSourceKey"
        val digest = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }

    /**
     * Copies [inputStream] into the job's `.part` staging file using a 64 KB buffer without
     * loading the entire media payload into memory.
     */
    suspend fun writeStreamToStagingFile(
        jobId: String,
        inputStream: InputStream
    ): File = withContext(Dispatchers.IO) {
        val stagingFile = allocateStagingFile(jobId)
        inputStream.use { input ->
            FileOutputStream(stagingFile).use { output ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    output.write(buffer, 0, read)
                }
                output.fd.sync()
            }
        }
        stagingFile
    }

    /**
     * Executes the complete recoverable validation + atomic promotion + transactional manifest commit
     * for a staged file belonging to [jobId].
     */
    suspend fun validatePromoteAndCommitJobAsset(
        jobId: String,
        stagingFile: File,
        expectedSha256Hex: String? = null,
        nowEpochMs: Long = System.currentTimeMillis()
    ): Result<AssetDescriptor> = withContext(Dispatchers.IO) {
        val jobDao = database.generationJobDao()
        val manifestDao = database.assetManifestDao()

        StorageReconciliationManager.markStagingJobActive(jobId)
        try {
            val job = jobDao.getJob(jobId)
                ?: return@withContext Result.failure(IllegalStateException("Job not found: $jobId"))

            // Transition to VALIDATING if currently in DOWNLOADING
            if (job.status == GenerationJobStatus.DOWNLOADING) {
                jobDao.transitionStatus(
                    jobId = jobId,
                    targetStatus = GenerationJobStatus.VALIDATING,
                    nowEpochMs = nowEpochMs
                )
            } else if (job.status == GenerationJobStatus.COMPLETED && !job.resultAssetId.isNullOrBlank()) {
                val existing = resolveAssetDescriptor(job.resultAssetId)
                if (existing != null) {
                    stagingFile.delete()
                    return@withContext Result.success(existing)
                }
            } else if (job.status != GenerationJobStatus.VALIDATING) {
                return@withContext Result.failure(
                    IllegalStateException("Job $jobId is in state ${job.status}, expected DOWNLOADING or VALIDATING.")
                )
            }

            // Check if an identical verified asset already exists for this scene by SHA-256
            if (stagingFile.exists() && stagingFile.length() >= MediaAssetValidator.MIN_VALID_MP4_BYTES) {
                val preSha = ChecksumVerifier.computeSha256(stagingFile).lowercase()
                if (!expectedSha256Hex.isNullOrBlank() && expectedSha256Hex.lowercase() != preSha) {
                    stagingFile.delete()
                    val msg = "SHA-256 checksum mismatch: expected ${expectedSha256Hex.lowercase()}, got $preSha"
                    jobDao.transitionStatus(
                        jobId = jobId,
                        targetStatus = GenerationJobStatus.FAILED,
                        errorMessage = msg,
                        nowEpochMs = nowEpochMs
                    )
                    return@withContext Result.failure(IllegalStateException(msg))
                }

                val existingDuplicate = manifestDao.getBySceneAndSha256(job.sceneId, preSha)
                if (existingDuplicate != null) {
                    val existingFile = File(baseFilesDir, existingDuplicate.relativePath)
                    if (existingFile.exists()) {
                        stagingFile.delete()
                        database.commitAssetManifestAndCompleteJob(
                            manifest = existingDuplicate,
                            jobId = jobId,
                            nowEpochMs = nowEpochMs
                        )
                        return@withContext Result.success(toDescriptor(existingDuplicate, existingFile))
                    }
                }
            }

            val nextVersion = manifestDao.getMaxVersionForScene(job.sceneId) + 1
            val cleanSceneId = job.sceneId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
            val assetId = String.format(Locale.US, "asset_%s_v%02d", cleanSceneId, nextVersion)

            // Step 1: Full validation (existence, size, SHA-256, MediaExtractor track, codec, frame, VFR PTS scan)
            val validation = MediaAssetValidator.validate(
                file = stagingFile,
                assetIdForPtsManifest = assetId,
                metadataDir = studioMetadataDir,
                expectedSha256Hex = expectedSha256Hex,
                inspector = validatorInspector
            )

            when (validation) {
                is MediaValidationResult.Invalid -> {
                    stagingFile.delete()
                    jobDao.transitionStatus(
                        jobId = jobId,
                        targetStatus = GenerationJobStatus.FAILED,
                        errorMessage = validation.reason,
                        nowEpochMs = nowEpochMs
                    )
                    return@withContext Result.failure(IllegalArgumentException(validation.reason))
                }
                is MediaValidationResult.Valid -> {
                    // Step 2: Atomic Promotion into studio_assets/<assetId>.mp4
                    val promotedFile = atomicPromoter.promote(
                        stagingFile = stagingFile,
                        assetId = assetId,
                        expectedSha256Hex = validation.sha256Hex
                    )

                    val ptsFile = File(studioMetadataDir, "$assetId.pts")
                    val manifest = AssetManifestEntity(
                        assetId = assetId,
                        sceneId = job.sceneId,
                        versionNumber = nextVersion,
                        relativePath = "studio_assets/${promotedFile.name}",
                        contentUri = SafeUri.toUriString(promotedFile),
                        sha256Hex = validation.sha256Hex,
                        byteSize = promotedFile.length(),
                        mimeType = "video/mp4",
                        width = validation.width,
                        height = validation.height,
                        durationMs = validation.durationMs,
                        nominalFps = validation.nominalFps,
                        isVfr = validation.isVfr,
                        ptsManifestPath = if (ptsFile.exists()) ptsFile.absolutePath else validation.ptsManifestUri?.path,
                        createdAtEpochMs = nowEpochMs
                    )

                    val committed = database.commitAssetManifestAndCompleteJob(
                        manifest = manifest,
                        jobId = jobId,
                        nowEpochMs = nowEpochMs
                    )
                    if (!committed) {
                        return@withContext Result.failure(
                            IllegalStateException("Failed to commit asset manifest & complete job $jobId transactionally.")
                        )
                    }

                    Result.success(toDescriptor(manifest, promotedFile))
                }
            }
        } catch (e: Exception) {
            stagingFile.delete()
            jobDao.transitionStatus(
                jobId = jobId,
                targetStatus = GenerationJobStatus.FAILED,
                errorMessage = e.localizedMessage ?: "Ingestion pipeline failure",
                nowEpochMs = nowEpochMs
            )
            Result.failure(e)
        } finally {
            StorageReconciliationManager.markStagingJobInactive(jobId)
        }
    }

    /**
     * Ingests a user-selected local MP4 URI (e.g. from Android Photo Picker) via ContentResolver
     * through the exact same staging -> SHA-256 -> MediaValidator -> VFR Detector -> Atomic Promotion
     * -> Room Manifest pipeline without requiring any network connection or API key.
     */
    suspend fun ingestLocalMp4Uri(
        context: Context,
        sceneId: String,
        sourceUri: Uri,
        nowEpochMs: Long = System.currentTimeMillis()
    ): Result<AssetDescriptor> = withContext(Dispatchers.IO) {
        val stream = try {
            context.contentResolver.openInputStream(sourceUri)
        } catch (e: Exception) {
            return@withContext Result.failure(
                IllegalArgumentException("Cannot open ContentResolver stream for URI: ${e.localizedMessage}")
            )
        } ?: return@withContext Result.failure(
            IllegalArgumentException("ContentResolver returned null InputStream for selected URI.")
        )

        ingestFromInputStream(
            sceneId = sceneId,
            inputStream = stream,
            sourceIdentifier = sourceUri.toString(),
            nowEpochMs = nowEpochMs
        )
    }

    /**
     * Ingests any [InputStream] for [sceneId] through a tracked local ingestion job in Room
     * (`QUEUED -> SUBMITTING -> SUBMITTED -> PROCESSING -> DOWNLOADING -> VALIDATING -> COMPLETED`).
     */
    suspend fun ingestFromInputStream(
        sceneId: String,
        inputStream: InputStream,
        sourceIdentifier: String,
        expectedSha256Hex: String? = null,
        nowEpochMs: Long = System.currentTimeMillis()
    ): Result<AssetDescriptor> = withContext(Dispatchers.IO) {
        val jobId = "local_import_${sceneId}_$nowEpochMs"
        val idempotencyKey = computeIdempotencyKey(
            sceneId = sceneId,
            providerId = "local_import",
            modelId = "content_resolver_mp4",
            prompt = "Local MP4 Import",
            seedOrSourceKey = "$sourceIdentifier|$nowEpochMs"
        )

        val jobDao = database.generationJobDao()
        val initialJob = GenerationJobEntity(
            jobId = jobId,
            idempotencyKey = idempotencyKey,
            sceneId = sceneId,
            providerId = "local_import",
            modelId = "content_resolver_mp4",
            prompt = "Local MP4 Import ($sourceIdentifier)",
            status = GenerationJobStatus.QUEUED,
            createdAtEpochMs = nowEpochMs,
            updatedAtEpochMs = nowEpochMs
        )
        jobDao.insertJobIfAbsent(initialJob)

        StorageReconciliationManager.markStagingJobActive(jobId)
        try {
            jobDao.transitionStatus(
                jobId = jobId,
                targetStatus = GenerationJobStatus.SUBMITTING,
                submissionAttemptedAtMs = nowEpochMs,
                nowEpochMs = nowEpochMs
            )
            jobDao.transitionStatus(
                jobId = jobId,
                targetStatus = GenerationJobStatus.SUBMITTED,
                providerOperationId = "local_stream:$jobId",
                nowEpochMs = nowEpochMs
            )
            jobDao.transitionStatus(
                jobId = jobId,
                targetStatus = GenerationJobStatus.PROCESSING,
                nowEpochMs = nowEpochMs
            )
            jobDao.transitionStatus(
                jobId = jobId,
                targetStatus = GenerationJobStatus.DOWNLOADING,
                nowEpochMs = nowEpochMs
            )

            val stagingFile = writeStreamToStagingFile(jobId, inputStream)
            validatePromoteAndCommitJobAsset(
                jobId = jobId,
                stagingFile = stagingFile,
                expectedSha256Hex = expectedSha256Hex,
                nowEpochMs = nowEpochMs
            )
        } finally {
            StorageReconciliationManager.markStagingJobInactive(jobId)
        }
    }

    /**
     * Resolves an immutable [AssetDescriptor] from Room by its [assetId] and verifies that the
     * underlying promoted file exists in `studio_assets/`.
     */
    suspend fun resolveAssetDescriptor(assetId: String): AssetDescriptor? = withContext(Dispatchers.IO) {
        val manifest = database.assetManifestDao().getByAssetId(assetId) ?: return@withContext null
        val file = File(baseFilesDir, manifest.relativePath)
        if (!file.exists() || !file.isFile) return@withContext null
        toDescriptor(manifest, file)
    }

    private fun toDescriptor(manifest: AssetManifestEntity, promotedFile: File): AssetDescriptor {
        val ptsUri = manifest.ptsManifestPath?.let { path ->
            val f = File(path)
            if (f.exists()) SafeUri.fromFile(f) else null
        }
        return AssetDescriptor(
            assetId = manifest.assetId,
            contentUri = SafeUri.fromFile(promotedFile),
            sha256Hex = manifest.sha256Hex,
            byteSize = manifest.byteSize,
            mimeType = manifest.mimeType,
            width = manifest.width,
            height = manifest.height,
            durationMs = manifest.durationMs,
            nominalFps = manifest.nominalFps,
            isVfr = manifest.isVfr,
            ptsManifestUri = ptsUri
        )
    }
}
