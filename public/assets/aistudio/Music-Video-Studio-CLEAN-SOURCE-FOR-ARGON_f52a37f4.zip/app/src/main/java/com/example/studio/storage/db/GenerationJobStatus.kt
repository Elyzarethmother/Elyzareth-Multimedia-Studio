package com.example.studio.storage.db

import androidx.room.TypeConverter

enum class GenerationJobStatus {
    QUEUED,
    SUBMITTING,
    SUBMITTED,
    PROCESSING,
    DOWNLOADING,
    VALIDATING,
    COMPLETED,
    FAILED,
    AMBIGUOUS_SUBMISSION_FAILED,
    CANCELLED;

    val isTerminal: Boolean
        get() = this == COMPLETED ||
            this == FAILED ||
            this == AMBIGUOUS_SUBMISSION_FAILED ||
            this == CANCELLED

    val isActiveInFlight: Boolean
        get() = !isTerminal

    companion object {
        fun isValidTransition(
            from: GenerationJobStatus,
            to: GenerationJobStatus
        ): Boolean {
            return when (from) {
                QUEUED ->
                    to == SUBMITTING ||
                    to == CANCELLED

                SUBMITTING ->
                    to == SUBMITTED ||
                    to == QUEUED ||
                    to == AMBIGUOUS_SUBMISSION_FAILED ||
                    to == FAILED

                SUBMITTED ->
                    to == PROCESSING ||
                    to == FAILED ||
                    to == CANCELLED

                PROCESSING ->
                    to == DOWNLOADING ||
                    to == FAILED ||
                    to == CANCELLED

                DOWNLOADING ->
                    to == VALIDATING ||
                    to == FAILED ||
                    to == CANCELLED

                VALIDATING ->
                    to == COMPLETED ||
                    to == FAILED ||
                    to == CANCELLED

                else -> false
            }
        }
    }
}

class GenerationJobStatusConverter {
    @TypeConverter
    fun fromStatus(status: GenerationJobStatus): String = status.name

    @TypeConverter
    fun toStatus(raw: String): GenerationJobStatus =
        GenerationJobStatus.valueOf(raw)
}
