package com.example.media

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.util.Log
import android.util.LruCache
import java.io.File

/**
 * Extracts and caches decoded video frames from per-scene MP4 clips (generated via Veo 3 API
 * or imported from Gemini/Flow) so both the real-time Preview Canvas and the H.264 `HdVideoExporter`
 * render genuine AI video frames for scenes that have a `videoClipPath`, while seamlessly mixing
 * with photo-animated scenes on the same `ProjectEdl`.
 */
object SceneVideoFrameExtractor {

    private const val TAG = "SceneVideoExtractor"

    // Cache quantized frames (e.g. at 12fps buckets per video file) to keep preview smooth
    private val frameCache = object : LruCache<String, Bitmap>(36) {}
    private val durationMsCache = mutableMapOf<String, Long>()

    @Synchronized
    fun getFrameAtSceneProgress(
        videoFilePath: String,
        sceneLocalProgress: Float
    ): Bitmap? {
        val file = File(videoFilePath)
        if (!file.exists() || file.length() < 256L) return null

        val clampedProgress = sceneLocalProgress.coerceIn(0f, 1f)
        val bucketIndex = (clampedProgress * 24f).toInt().coerceIn(0, 24)
        val cacheKey = "${file.absolutePath}@$bucketIndex"

        frameCache.get(cacheKey)?.let { cached ->
            if (!cached.isRecycled) return cached
        }

        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durationMs = durationMsCache.getOrPut(file.absolutePath) {
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    ?.toLongOrNull()
                    ?.coerceAtLeast(500L)
                    ?: 5_000L
            }
            val targetTimeUs = ((clampedProgress * durationMs) * 1000L).toLong()
                .coerceIn(0L, (durationMs - 50L).coerceAtLeast(0L) * 1000L)

            val rawFrame = retriever.getFrameAtTime(
                targetTimeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            ) ?: retriever.getFrameAtTime(targetTimeUs)

            if (rawFrame != null) {
                // Downscale huge frames to <= 1280px longest edge to keep LruCache lightweight
                val maxDim = 1280
                val w = rawFrame.width.coerceAtLeast(1)
                val h = rawFrame.height.coerceAtLeast(1)
                val stored = if (w > maxDim || h > maxDim) {
                    val scale = maxDim.toFloat() / maxOf(w, h).toFloat()
                    Bitmap.createScaledBitmap(
                        rawFrame,
                        (w * scale).toInt().coerceAtLeast(1),
                        (h * scale).toInt().coerceAtLeast(1),
                        true
                    )
                } else {
                    rawFrame
                }
                frameCache.put(cacheKey, stored)
                stored
            } else {
                null
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to extract frame from scene video: $videoFilePath", e)
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }
}
