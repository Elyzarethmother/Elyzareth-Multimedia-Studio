package com.example.studio.storage.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        GenerationJobEntity::class,
        AssetManifestEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(GenerationJobStatusConverter::class)
abstract class StudioDatabase : RoomDatabase() {

    abstract fun generationJobDao(): GenerationJobDao
    abstract fun assetManifestDao(): AssetManifestDao

    /**
     * Atomically inserts the immutable [AssetManifestEntity] and transitions the owning
     * [GenerationJobEntity] from `VALIDATING` to `COMPLETED` in one SQLite transaction.
     */
    @Transaction
    open suspend fun commitAssetManifestAndCompleteJob(
        manifest: AssetManifestEntity,
        jobId: String,
        nowEpochMs: Long = System.currentTimeMillis()
    ): Boolean {
        val jobDao = generationJobDao()
        val manifestDao = assetManifestDao()

        val currentJob = jobDao.getJob(jobId) ?: return false
        if (!GenerationJobStatus.isValidTransition(currentJob.status, GenerationJobStatus.COMPLETED)) {
            return false
        }

        val existingManifest = manifestDao.getByAssetId(manifest.assetId)
        if (existingManifest != null && existingManifest.sha256Hex != manifest.sha256Hex) {
            throw IllegalStateException(
                "Immutable assetId collision: ${manifest.assetId} already exists with different SHA-256."
            )
        }
        if (existingManifest == null) {
            manifestDao.insertManifestIfAbsent(manifest)
        }

        return jobDao.transitionStatus(
            jobId = jobId,
            targetStatus = GenerationJobStatus.COMPLETED,
            resultAssetId = manifest.assetId,
            errorMessage = null,
            nowEpochMs = nowEpochMs
        )
    }

    companion object {
        private const val DATABASE_NAME = "music_video_studio_assets.db"

        /**
         * Explicit forward migration registry. Destructive migrations are strictly prohibited
         * in production configuration to protect immutable asset manifests and job ledgers.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Reserved for explicit non-destructive schema evolution from v1 -> v2
            }
        }

        @Volatile
        private var INSTANCE: StudioDatabase? = null

        fun getInstance(context: Context): StudioDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StudioDatabase::class.java,
                    DATABASE_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
