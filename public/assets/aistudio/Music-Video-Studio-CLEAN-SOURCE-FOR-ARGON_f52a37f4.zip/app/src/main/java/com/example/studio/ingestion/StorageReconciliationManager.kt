package com.example.studio.ingestion

import android.net.Uri
import com.example.studio.storage.db.AssetManifestEntity
import com.example.studio.storage.db.GenerationJobStatus
import com.example.studio.storage.db.StudioDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Collections

data class ReconciliationSummary(
    val interruptedSubmittingJobsMarkedAmbiguous: Int,
    val orphanedAssetsRegistered: Int,
    val corruptOrphansQuarantined: Int,
    val staleStagingFilesDeleted: Int,
    val activeStagingFilesPreserved: Int
)

/**
 * Handles crash recovery and startup reconciliation between the filesystem (`filesDir`)
 * and `StudioDatabase`:
 * 1. Marks any interrupted `SUBMITTING` job (with no `providerOperationId`) as `AMBIGUOUS_SUBMISSION_FAILED`.
 * 2. Inspects `filesDir/studio_assets/<assetId>.mp4` for promoted files whose process terminated between
 *    Step 2 (atomic file promotion) and Step 3 (Room manifest transaction):
 *    - Validates the promoted file and completes its `AssetManifestEntity` registration (and job completion).
 *    - Quarantines corrupt files without ever deleting a valid promoted asset referenced by a manifest or EDL.
 * 3. Sweeps `filesDir/.staging_tmp/<job>.part` safely:
 *    - Never deletes staging files owned by an active worker, an active job, or younger than [staleStagingMaxAgeMs].
 *    - Handles `listFiles() == null` safely.
 */
class StorageReconciliationManager(
    private val baseFilesDir: File,
    private val database: StudioDatabase,
    private val validatorInspector: VideoContainerInspector = MediaAssetValidator.defaultInspector
) {

    val stagingDir: File = File(baseFilesDir, ".staging_tmp")
    val studioAssetsDir: File = File(baseFilesDir, "studio_assets")
    val studioMetadataDir: File = File(baseFilesDir, "studio_metadata")
    val quarantineDir: File = File(baseFilesDir, ".quarantine")

    companion object {
        const val DEFAULT_STALE_STAGING_MAX_AGE_MS = 30 * 60 * 1000L // 30 minutes

        private val activeWorkerStagingJobIds: MutableSet<String> =
            Collections.synchronizedSet(HashSet())

        fun markStagingJobActive(jobId: String) {
            activeWorkerStagingJobIds.add(jobId)
        }

        fun markStagingJobInactive(jobId: String) {
            activeWorkerStagingJobIds.remove(jobId)
        }

        fun isStagingJobActiveInWorker(jobId: String): Boolean =
            activeWorkerStagingJobIds.contains(jobId)
    }

    suspend fun reconcileStorageAndDatabase(
        nowEpochMs: Long = System.currentTimeMillis(),
        staleStagingMaxAgeMs: Long = DEFAULT_STALE_STAGING_MAX_AGE_MS,
        protectedAssetIdsFromEdl: Set<String> = emptySet()
    ): ReconciliationSummary = withContext(Dispatchers.IO) {
        stagingDir.mkdirs()
        studioAssetsDir.mkdirs()
        studioMetadataDir.mkdirs()

        val jobDao = database.generationJobDao()
        val manifestDao = database.assetManifestDao()

        // 1. Transition any interrupted SUBMITTING jobs (without providerOperationId) to AMBIGUOUS_SUBMISSION_FAILED
        var ambiguousCount = 0
        val submittingJobs = jobDao.getJobsByStatuses(listOf(GenerationJobStatus.SUBMITTING))
        for (job in submittingJobs) {
            if (!isStagingJobActiveInWorker(job.jobId) && job.providerOperationId.isNullOrBlank()) {
                if (jobDao.markInterruptedSubmittingJobAmbiguous(job.jobId, nowEpochMs = nowEpochMs)) {
                    ambiguousCount++
                }
            }
        }

        // 2. Reconcile orphaned promoted files in studio_assets/
        var registeredOrphans = 0
        var quarantinedOrphans = 0
        val existingManifestsById = manifestDao.getAllManifests().associateBy { it.assetId }
        val promotedFiles = studioAssetsDir.listFiles() ?: emptyArray()

        for (file in promotedFiles) {
            if (!file.isFile || !file.name.endsWith(".mp4")) continue
            val assetId = file.nameWithoutExtension
            if (existingManifestsById.containsKey(assetId)) {
                continue // Already registered in Room manifest
            }

            // Validate the promoted orphan file
            val validation = MediaAssetValidator.validate(
                file = file,
                assetIdForPtsManifest = assetId,
                metadataDir = studioMetadataDir,
                expectedSha256Hex = null,
                inspector = validatorInspector
            )
            when (validation) {
                is MediaValidationResult.Valid -> {
                    val parsedSceneId = parseSceneIdFromAssetId(assetId)
                    val parsedVersion = parseVersionFromAssetId(assetId)
                        ?: (manifestDao.getMaxVersionForScene(parsedSceneId) + 1)

                    val ptsFile = File(studioMetadataDir, "$assetId.pts")
                    val recoveredManifest = AssetManifestEntity(
                        assetId = assetId,
                        sceneId = parsedSceneId,
                        versionNumber = parsedVersion,
                        relativePath = "studio_assets/${file.name}",
                        contentUri = SafeUri.toUriString(file),
                        sha256Hex = validation.sha256Hex,
                        byteSize = file.length(),
                        mimeType = "video/mp4",
                        width = validation.width,
                        height = validation.height,
                        durationMs = validation.durationMs,
                        nominalFps = validation.nominalFps,
                        isVfr = validation.isVfr,
                        ptsManifestPath = if (ptsFile.exists()) ptsFile.absolutePath else validation.ptsManifestUri?.path,
                        createdAtEpochMs = nowEpochMs
                    )
                    manifestDao.insertManifestIfAbsent(recoveredManifest)

                    // Check if a job in VALIDATING / DOWNLOADING for the same scene was interrupted right before commit
                    val validatingJobs = jobDao.getJobsByStatuses(
                        listOf(GenerationJobStatus.VALIDATING, GenerationJobStatus.DOWNLOADING)
                    ).filter { it.sceneId == parsedSceneId && !isStagingJobActiveInWorker(it.jobId) }

                    for (vJob in validatingJobs) {
                        if (vJob.status == GenerationJobStatus.DOWNLOADING) {
                            jobDao.transitionStatus(vJob.jobId, GenerationJobStatus.VALIDATING, nowEpochMs = nowEpochMs)
                        }
                        jobDao.transitionStatus(
                            jobId = vJob.jobId,
                            targetStatus = GenerationJobStatus.COMPLETED,
                            resultAssetId = assetId,
                            nowEpochMs = nowEpochMs
                        )
                    }
                    registeredOrphans++
                }
                is MediaValidationResult.Invalid -> {
                    // Never delete an asset if protected by an EDL snapshot; otherwise move to quarantine
                    if (assetId !in protectedAssetIdsFromEdl) {
                        quarantineDir.mkdirs()
                        val quarantinedFile = File(quarantineDir, "${file.name}.quarantined_$nowEpochMs")
                        file.renameTo(quarantinedFile)
                        quarantinedOrphans++
                    }
                }
            }
        }

        // 3. Sweep stale staging files in .staging_tmp/
        val activeJobsById = jobDao.getJobsByStatuses(
            listOf(
                GenerationJobStatus.QUEUED,
                GenerationJobStatus.SUBMITTING,
                GenerationJobStatus.SUBMITTED,
                GenerationJobStatus.PROCESSING,
                GenerationJobStatus.DOWNLOADING,
                GenerationJobStatus.VALIDATING
            )
        ).associateBy { it.jobId }

        var deletedStagingCount = 0
        var preservedStagingCount = 0
        val stagingFiles = stagingDir.listFiles() ?: emptyArray()

        for (stagingFile in stagingFiles) {
            if (!stagingFile.isFile) continue
            val jobId = parseJobIdFromStagingFileName(stagingFile.name)
            val ageMs = (nowEpochMs - stagingFile.lastModified()).coerceAtLeast(0L)

            val isOwnedByActiveWorker = jobId != null && isStagingJobActiveInWorker(jobId)
            val isOwnedByActiveJob = jobId != null && activeJobsById.containsKey(jobId)
            val isYoungFile = ageMs < staleStagingMaxAgeMs

            if (isOwnedByActiveWorker || isOwnedByActiveJob || isYoungFile) {
                preservedStagingCount++
            } else {
                if (stagingFile.delete()) {
                    deletedStagingCount++
                }
            }
        }

        ReconciliationSummary(
            interruptedSubmittingJobsMarkedAmbiguous = ambiguousCount,
            orphanedAssetsRegistered = registeredOrphans,
            corruptOrphansQuarantined = quarantinedOrphans,
            staleStagingFilesDeleted = deletedStagingCount,
            activeStagingFilesPreserved = preservedStagingCount
        )
    }

    private fun parseJobIdFromStagingFileName(fileName: String): String? {
        if (!fileName.startsWith("job_") || !fileName.endsWith(".part")) return null
        return fileName.removePrefix("job_").removeSuffix(".part").takeIf { it.isNotBlank() }
    }

    private fun parseSceneIdFromAssetId(assetId: String): String {
        // Matches e.g. "asset_scene_1_v02" -> "scene_1"
        val withoutPrefix = assetId.removePrefix("asset_")
        val versionSplit = withoutPrefix.lastIndexOf("_v")
        return if (versionSplit > 0) {
            withoutPrefix.substring(0, versionSplit)
        } else {
            withoutPrefix.ifBlank { "scene_recovered" }
        }
    }

    private fun parseVersionFromAssetId(assetId: String): Int? {
        val versionSplit = assetId.lastIndexOf("_v")
        if (versionSplit < 0 || versionSplit + 2 >= assetId.length) return null
        return assetId.substring(versionSplit + 2).takeWhile { it.isDigit() }.toIntOrNull()
    }
}
