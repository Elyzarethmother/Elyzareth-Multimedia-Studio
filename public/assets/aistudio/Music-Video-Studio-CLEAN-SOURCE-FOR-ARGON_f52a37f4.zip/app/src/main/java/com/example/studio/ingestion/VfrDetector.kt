package com.example.studio.ingestion

import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import kotlin.math.abs

data class VfrAnalysisReport(
    val sampleCount: Int,
    val nominalFps: Float,
    val medianDeltaUs: Long,
    val minDeltaUs: Long,
    val maxDeltaUs: Long,
    val maxJitterRatio: Float,
    val irregularIntervalCount: Int,
    val nonMonotonicOrDuplicateCount: Int,
    val isVfr: Boolean,
    val boundedPtsDeltasUs: LongArray
) {
    /**
     * Serializes the bounded delta-encoded PTS manifest to a compact text format:
     * Header line: `v1|fps=<nominalFps>|medianUs=<medianDeltaUs>|vfr=<isVfr>|count=<N>`
     * Body line: comma-separated delta microseconds (`d0,d1,d2,...`) capped at [VfrDetector.MAX_PTS_MANIFEST_SAMPLES].
     */
    fun serializeCompactManifest(): String {
        val sb = StringBuilder(boundedPtsDeltasUs.size * 6 + 64)
        sb.append("v1|fps=").append(String.format(java.util.Locale.US, "%.3f", nominalFps))
            .append("|medianUs=").append(medianDeltaUs)
            .append("|vfr=").append(isVfr)
            .append("|nonMono=").append(nonMonotonicOrDuplicateCount)
            .append("|count=").append(boundedPtsDeltasUs.size)
            .append('\n')
        for (i in boundedPtsDeltasUs.indices) {
            if (i > 0) sb.append(',')
            sb.append(boundedPtsDeltasUs[i])
        }
        return sb.toString()
    }
}

object VfrDetector {

    /**
     * Maximum number of frame intervals stored in a `.pts` manifest file (3,600 samples =
     * 150 seconds at 24fps, keeping every `.pts` file strictly under 32 KB on disk).
     */
    const val MAX_PTS_MANIFEST_SAMPLES = 3_600

    /**
     * Maximum number of samples read from `MediaExtractor` during ingest inspection.
     */
    const val MAX_EXTRACTOR_SCAN_SAMPLES = 7_200

    /**
     * Frame interval deviation threshold (15% from median interval) above which a frame step
     * is counted as an irregular presentation interval.
     */
    const val JITTER_THRESHOLD_RATIO = 0.15f

    /**
     * Extracts presentation timestamps from the first video track of [videoFile] using
     * [MediaExtractor] without decoding frame bitmaps into memory.
     */
    fun analyzeVideoFile(videoFile: File): VfrAnalysisReport {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(videoFile.absolutePath)
            var videoTrackIndex = -1
            var declaredFrameRate = 0f

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("video/")) {
                    videoTrackIndex = i
                    if (format.containsKey(MediaFormat.KEY_FRAME_RATE)) {
                        declaredFrameRate = try {
                            format.getInteger(MediaFormat.KEY_FRAME_RATE).toFloat()
                        } catch (_: Exception) {
                            try {
                                format.getFloat(MediaFormat.KEY_FRAME_RATE)
                            } catch (_: Exception) {
                                0f
                            }
                        }
                    }
                    break
                }
            }

            if (videoTrackIndex < 0) {
                return analyzePresentationTimestamps(emptyList(), declaredFrameRate)
            }

            extractor.selectTrack(videoTrackIndex)
            val timestampsUs = ArrayList<Long>(512)
            while (timestampsUs.size < MAX_EXTRACTOR_SCAN_SAMPLES) {
                val sampleTimeUs = extractor.sampleTime
                if (sampleTimeUs < 0L) break
                timestampsUs.add(sampleTimeUs)
                if (!extractor.advance()) break
            }
            return analyzePresentationTimestamps(timestampsUs, declaredFrameRate)
        } finally {
            try {
                extractor.release()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Pure deterministic analyzer over raw presentation timestamps (in microseconds).
     * Detects:
     * - Nominal frame rate & median frame interval
     * - Irregular presentation intervals (>15% deviation from median interval)
     * - Duplicate (`delta == 0`) or non-monotonic (`delta < 0`) presentation timestamps
     * - VFR classification
     */
    fun analyzePresentationTimestamps(
        rawPtsUs: List<Long>,
        fallbackFps: Float = 24f
    ): VfrAnalysisReport {
        val safeFallbackFps = if (fallbackFps in 1f..240f) fallbackFps else 24f
        if (rawPtsUs.size < 2) {
            val defaultDelta = (1_000_000f / safeFallbackFps).toLong()
            return VfrAnalysisReport(
                sampleCount = rawPtsUs.size,
                nominalFps = safeFallbackFps,
                medianDeltaUs = defaultDelta,
                minDeltaUs = defaultDelta,
                maxDeltaUs = defaultDelta,
                maxJitterRatio = 0f,
                irregularIntervalCount = 0,
                nonMonotonicOrDuplicateCount = 0,
                isVfr = false,
                boundedPtsDeltasUs = LongArray(0)
            )
        }

        // 1. Check for non-monotonic or duplicate timestamps in raw sample order
        var nonMonotonicOrDuplicateCount = 0
        for (i in 1 until rawPtsUs.size) {
            if (rawPtsUs[i] <= rawPtsUs[i - 1]) {
                nonMonotonicOrDuplicateCount++
            }
        }

        // 2. Sort presentation timestamps (B-frames in H.264/HEVC can arrive in decode order
        //    rather than presentation order; sorting yields presentation-order intervals,
        //    while duplicate PTS after sorting still indicates duplicate timestamps).
        val sortedPts = rawPtsUs.sorted()
        var duplicatePresentationPtsCount = 0
        val positiveDeltas = ArrayList<Long>(sortedPts.size - 1)
        val boundedDeltas = LongArray(minOf(sortedPts.size - 1, MAX_PTS_MANIFEST_SAMPLES))

        for (i in 1 until sortedPts.size) {
            val delta = sortedPts[i] - sortedPts[i - 1]
            if (i - 1 < boundedDeltas.size) {
                boundedDeltas[i - 1] = delta
            }
            if (delta <= 0L) {
                duplicatePresentationPtsCount++
            } else {
                positiveDeltas.add(delta)
            }
        }

        if (positiveDeltas.isEmpty()) {
            val defaultDelta = (1_000_000f / safeFallbackFps).toLong()
            return VfrAnalysisReport(
                sampleCount = rawPtsUs.size,
                nominalFps = safeFallbackFps,
                medianDeltaUs = defaultDelta,
                minDeltaUs = 0L,
                maxDeltaUs = 0L,
                maxJitterRatio = 1f,
                irregularIntervalCount = sortedPts.size - 1,
                nonMonotonicOrDuplicateCount = maxOf(nonMonotonicOrDuplicateCount, duplicatePresentationPtsCount),
                isVfr = true,
                boundedPtsDeltasUs = boundedDeltas
            )
        }

        val sortedDeltas = positiveDeltas.sorted()
        val medianDeltaUs = sortedDeltas[sortedDeltas.size / 2].coerceAtLeast(1L)
        val minDeltaUs = sortedDeltas.first()
        val maxDeltaUs = sortedDeltas.last()
        val nominalFps = (1_000_000f / medianDeltaUs.toFloat()).coerceIn(1f, 240f)

        var maxJitterRatio = 0f
        var irregularIntervalCount = 0
        for (delta in positiveDeltas) {
            val jitter = abs(delta - medianDeltaUs).toFloat() / medianDeltaUs.toFloat()
            if (jitter > maxJitterRatio) {
                maxJitterRatio = jitter
            }
            if (jitter > JITTER_THRESHOLD_RATIO) {
                irregularIntervalCount++
            }
        }

        val isVfr = duplicatePresentationPtsCount > 0 ||
            nonMonotonicOrDuplicateCount > 0 ||
            irregularIntervalCount > 0 ||
            maxJitterRatio > JITTER_THRESHOLD_RATIO

        return VfrAnalysisReport(
            sampleCount = rawPtsUs.size,
            nominalFps = nominalFps,
            medianDeltaUs = medianDeltaUs,
            minDeltaUs = minDeltaUs,
            maxDeltaUs = maxDeltaUs,
            maxJitterRatio = maxJitterRatio,
            irregularIntervalCount = irregularIntervalCount,
            nonMonotonicOrDuplicateCount = maxOf(nonMonotonicOrDuplicateCount, duplicatePresentationPtsCount),
            isVfr = isVfr,
            boundedPtsDeltasUs = boundedDeltas
        )
    }

    /**
     * Writes the compact `.pts` manifest to [metadataDir]/`[assetId].pts`.
     */
    fun writePtsManifestFile(
        metadataDir: File,
        assetId: String,
        report: VfrAnalysisReport
    ): File {
        metadataDir.mkdirs()
        val safeId = assetId.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val ptsFile = File(metadataDir, "$safeId.pts")
        ptsFile.writeText(report.serializeCompactManifest(), Charsets.UTF_8)
        return ptsFile
    }
}
